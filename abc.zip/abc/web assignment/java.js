<script>
function toggleMenu() {
    const navMenu = document.querySelector('header nav ul');
    navMenu.classList.toggle('active');
}
</script>
